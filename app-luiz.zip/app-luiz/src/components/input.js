import { TextInput } from 'react-native';

export default function Input() {
  return(
    <TextInput />
  );
}