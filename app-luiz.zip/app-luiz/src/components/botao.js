import { Button } from "react-native";

export default function Botao() {
  return(
    <Button />
  );
}