import { View } from 'react-native';
import Input from '../components/input';
import Botao from '../components/botao';

export default function Login() {
  return (
    <View>
      <Input />
      <Input />
      <Input />
      <Input />
      <Botao />
      <Botao />
    </View>
  );
}
